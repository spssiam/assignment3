-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 09, 2022 at 02:31 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `siam`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `name`) VALUES
(1, '2022'),
(2, '2018'),
(3, '2014'),
(4, '2010'),
(7, '2006'),
(8, '2002');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

CREATE TABLE `tbl_contact` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_contact`
--

INSERT INTO `tbl_contact` (`id`, `firstname`, `lastname`, `email`, `body`, `status`, `date`) VALUES
(8, 'Abdur', 'Rahman', 'abdurrahman@gmail.com', 'Hello I am Abdur Rahman. You are doing a great job in this blog. I really appreciate your work. Keep it up.', 1, '2021-11-30 14:09:02'),
(9, 'Rodela', 'Jaman', 'rodela@yahoo.com', 'Hi I am Rodela. I read your posts daily and they are fantastic. I am also an editor in this sector and please let me know if you need an editor in the future. Best regards.', 1, '2021-11-30 14:11:41'),
(10, 'Naim', 'Khan', 'naim@outlook.com', 'Hello Tech Daily. Your site is great for knowing up to date information about technologies. Very good. Keep up the good work.', 1, '2021-11-30 14:19:04');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_footer`
--

CREATE TABLE `tbl_footer` (
  `id` int(11) NOT NULL,
  `note` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_footer`
--

INSERT INTO `tbl_footer` (`id`, `note`) VALUES
(1, 'Copyright FifaFever.');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_page`
--

CREATE TABLE `tbl_page` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `body` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_page`
--

INSERT INTO `tbl_page` (`id`, `name`, `body`) VALUES
(1, 'About Us', '<p><strong>Admin</strong>&nbsp; Shahede Parveze Siam</p>\r\n<p>&nbsp;</p>\r\n<p><strong>Authors</strong>&nbsp; Al-amin,siam, faysal,anis,monir</p>\r\n<p><strong>Editors</strong>&nbsp; Saidur,Kazi</p>\r\n<p>&nbsp;</p>'),
(2, 'Privacy Policy', '<p><span>F&eacute;d&eacute;ration Internationale de Football Association (FIFA)</span><br /><span>FIFA-Strasse 20</span><br /><span>8044 Zurich</span><br /><span>Switzerland</span></p>\r\n<p><span>Please read the following to learn more about the ways FIFA uses your personal data before you proceed with the use of the FIFA RED portal.</span></p>\r\n<p><span>This Data Protection Policy has been drafted in English and has been translated into other languages. In the event of discrepancies between the English and the translated texts, the English text shall prevail and be used to solve doubts of interpretation.</span></p>\r\n<p><span>Date of issue of this Data Protection Policy: October 2020</span></p>\r\n<p><span><span>International Transfer</span></span></p>\r\n<p><span>YOUR INFORMATION IS PROCESSED IN SWITZERLAND AND IN THE EUROPEAN ECONOMIC AREA (&ldquo;EEA&rdquo;), AND MAY BE PROCESSED ELSEWHERE DEPENDING ON THE LOCATION OF AFFILIATES, BUSINESS PARTNERS, AND OTHER ENTITIES WHO ARE PERMITTED TO ACCESS SUCH INFORMATION UNDER THE TERMS OF THIS DATA PROTECTION POLICY (LOCATIONS OUTSIDE THE EEA MAY INCLUDE COUNTRIES WHICH MAY NOT ASSURE AN ADEQUATE LEVEL OF DATA PROTECTION ACCORDING TO APPLICABLE LAWS IN THE EEA AND SWITZERLAND). IF FIFA PROCESSES YOUR PERSONAL INFORMATION OUTSIDE THE EEA, ALL REASONABLE STEPS WILL BE TAKEN TO ENSURE THAT YOUR PERSONAL INFORMATION IS TREATED AS SAFELY AND SECURELY AS IT WOULD BE WITHIN THE EEA AND SWITZERLAND AND UNDER THE SWISS DATA PROTECTION ACT (&ldquo;DPA&rdquo;) AND THE GENERAL DATA PROTECTION REGULATION (&ldquo;GDPR&rdquo;).</span></p>\r\n<p><span><span>The collection of personal data and how FIFA uses it</span></span></p>\r\n<p><span>The processing, collection and use of your personal data will always have a lawful basis. This lawful basis can be FIFA&rsquo;s performance of a contract with you, your freely given consent, compliance with a legal obligation or FIFA&rsquo;s legitimate interest.</span></p>\r\n<p><span>Specifically, FIFA may use your personal data for the following purposes:</span></p>\r\n<ul>\r\n<li><span>to provide and receive feedback in order to improve the FIFA RED portal;</span></li>\r\n<li><span>to provide and feature FIFA content, such as FIFA World Cup videos;</span></li>\r\n<li><span>to manage your membership in the FIFA RED portal;</span></li>\r\n<li><span>to enable you to enjoy and easily navigate the FIFA RED portal;</span></li>\r\n<li><span>to ensure appropriate customer care;</span></li>\r\n<li><span>to provide you with services you request;</span></li>\r\n<li><span>to manage your account in the FIFA RED portal;</span></li>\r\n<li><span>to communicate with you in general;</span></li>\r\n<li><span>to respond to your questions and comments;</span></li>\r\n<li><span>to notify you about new educational content that may be of interest to you;</span></li>\r\n<li><span>to prevent potentially prohibited or illegal activities;</span></li>\r\n<li><span>to enforce our terms located at&nbsp;<span><a href=\"https://red.fifa.com/terms-of-use\" rel=\"noopener\" target=\"_blank\">https://red.fifa.com/terms-of-use</a></span>; and</span></li>\r\n<li><span>as otherwise described to you at the point of collection of the personal data.</span></li>\r\n</ul>\r\n<p><span><span>The personal data FIFA collects from you</span></span></p>\r\n<p><span>The personal data FIFA collects form you when you use FIFA&rsquo;s websites may include but is not limited to the following categories of personal data:</span></p>\r\n<p><span>For the use of the FIFA RED portal: email address, last name, first name, country of residence, age range, gender, roles, level, password, IP address, FIFA content preferences.</span></p>'),
(3, 'Terms Of Use', '<p><span>A terms of use agreement defines rules for the use of a website. Sometimes referred to as &ldquo;terms and conditions,&rdquo; this document includes disclaimers and notices clarifying the limit of the website&rsquo;s or business&rsquo;s liability to the visitor. It also often displays other information about website ownership and copyright to help protect a website&rsquo;s content. And it may contain a privacy policy explaining how you collect and use customer or visitor information. Because of the specific language and the diversity in the range of websites&rsquo; needs, these documents should be created with the help of legal experts for maximum legal protection.</span></p>\r\n<p>Some sites present a pop-up or a landing page requiring visitors to agree to terms and conditions before proceeding, which is called a &ldquo;clickwrap agreement.&rdquo; It&rsquo;s more common to find websites with a &ldquo;browsewrap agreement.&rdquo; With these, visitors are not prompted to view or to agree to anything but can access a terms of use page by browsing for a link if they so choose. In this case, a hyperlink or button is often buried at the bottom of a home page and remains unseen by most visitors.</p>\r\n<p>One middle ground option for presentation is a subdued pop-up or banner with a notice that by continuing to use the site, a user agrees to the terms of use. These often contain a hyperlink to the page with the terms of use. Regardless of presentation, each type of agreement contains much of the same content. Either way, if website visitors don&rsquo;t approve of the specific conditions set forth in the agreement, they are free to leave.</p>');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_post`
--

CREATE TABLE `tbl_post` (
  `id` int(11) NOT NULL,
  `cat` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `author` varchar(50) NOT NULL,
  `tags` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_post`
--

INSERT INTO `tbl_post` (`id`, `cat`, `title`, `body`, `image`, `author`, `tags`, `date`, `userid`) VALUES
(16, 2, '2018 FIFA World Cup', '<p>The&nbsp;<strong>2018 FIFA World Cup</strong>&nbsp;was an international&nbsp;<a title=\"Association football\" href=\"https://en.wikipedia.org/wiki/Association_football\">football</a>&nbsp;tournament contested by&nbsp;<a title=\"List of men\'s national association football teams\" href=\"https://en.wikipedia.org/wiki/List_of_men%27s_national_association_football_teams\">men\'s national teams</a>&nbsp;that took place between 14 June and 15 July 2018 in Russia. It was the 21st&nbsp;<a title=\"FIFA World Cup\" href=\"https://en.wikipedia.org/wiki/FIFA_World_Cup\">FIFA World Cup</a>, a worldwide football tournament held once every four years. It was the eleventh time the championships had been held in Europe, and the first time they were held in Eastern Europe. At an estimated cost of over $14.2&nbsp;billion, it was the most expensive World Cup to date.<sup id=\"cite_ref-1\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/2018_FIFA_World_Cup#cite_note-1\">[1]</a></sup><sup id=\"cite_ref-2\" class=\"reference\"><a href=\"https://en.wikipedia.org/wiki/2018_FIFA_World_Cup#cite_note-2\">[2]</a></sup></p>\r\n<p>The tournament phase involved 32 teams, of which 31 came through&nbsp;<a title=\"2018 FIFA World Cup qualification\" href=\"https://en.wikipedia.org/wiki/2018_FIFA_World_Cup_qualification\">qualifying competitions</a>, while as the host nation&nbsp;<a title=\"Russia national football team\" href=\"https://en.wikipedia.org/wiki/Russia_national_football_team\">Russia</a>&nbsp;qualified automatically. Of the 32, 20 had also appeared in the&nbsp;<a title=\"2014 FIFA World Cup\" href=\"https://en.wikipedia.org/wiki/2014_FIFA_World_Cup\">2014 event</a>, while&nbsp;<a title=\"Iceland national football team\" href=\"https://en.wikipedia.org/wiki/Iceland_national_football_team\">Iceland</a>&nbsp;and&nbsp;<a title=\"Panama national football team\" href=\"https://en.wikipedia.org/wiki/Panama_national_football_team\">Panama</a>&nbsp;each made their first appearance at the World Cup. 64 matches were played in 12 venues across 11 cities.&nbsp;<a title=\"Germany national football team\" href=\"https://en.wikipedia.org/wiki/Germany_national_football_team\">Germany</a>, the defending champions, were eliminated in the group stage. Host nation Russia was eliminated in the quarter-finals. In the&nbsp;<a title=\"2018 FIFA World Cup Final\" href=\"https://en.wikipedia.org/wiki/2018_FIFA_World_Cup_Final\">final</a>,&nbsp;<a title=\"France national football team\" href=\"https://en.wikipedia.org/wiki/France_national_football_team\">France</a>&nbsp;played&nbsp;<a title=\"Croatia national football team\" href=\"https://en.wikipedia.org/wiki/Croatia_national_football_team\">Croatia</a>&nbsp;on 15 July at the&nbsp;<a title=\"Luzhniki Stadium\" href=\"https://en.wikipedia.org/wiki/Luzhniki_Stadium\">Luzhniki Stadium</a>&nbsp;in&nbsp;<a title=\"Moscow\" href=\"https://en.wikipedia.org/wiki/Moscow\">Moscow</a>. France won the match 4&ndash;2, claiming their second World Cup.</p>\r\n<p>Croatian player&nbsp;<a title=\"Luka Modrić\" href=\"https://en.wikipedia.org/wiki/Luka_Modri%C4%87\">Luka Modrić</a>&nbsp;was voted the tournament\'s best player, winning the&nbsp;<a class=\"mw-redirect\" title=\"FIFA World Cup Golden Ball\" href=\"https://en.wikipedia.org/wiki/FIFA_World_Cup_Golden_Ball\">Golden Ball</a>. England\'s&nbsp;<a title=\"Harry Kane\" href=\"https://en.wikipedia.org/wiki/Harry_Kane\">Harry Kane</a>&nbsp;won the&nbsp;<a class=\"mw-redirect\" title=\"FIFA World Cup Golden Boot\" href=\"https://en.wikipedia.org/wiki/FIFA_World_Cup_Golden_Boot\">Golden Boot</a>&nbsp;as he scored the most goals during the tournament with six. Belgium\'s&nbsp;<a title=\"Thibaut Courtois\" href=\"https://en.wikipedia.org/wiki/Thibaut_Courtois\">Thibaut Courtois</a>&nbsp;won the&nbsp;<a class=\"mw-redirect\" title=\"FIFA World Cup Golden Glove\" href=\"https://en.wikipedia.org/wiki/FIFA_World_Cup_Golden_Glove\">Golden Glove</a>, awarded to the&nbsp;<a title=\"Goalkeeper (association football)\" href=\"https://en.wikipedia.org/wiki/Goalkeeper_(association_football)\">goalkeeper</a>&nbsp;with the most&nbsp;<a class=\"mw-redirect\" title=\"Clean sheet\" href=\"https://en.wikipedia.org/wiki/Clean_sheet\">clean sheets</a>. It has been estimated that more than 3&nbsp;million people attended games during the tournament.</p>', 'upload/0d6f662c67.jpg', 'Faysal', '2018', '2021-11-28 17:35:48', 1),
(29, 1, 'Can Tunisia finally manage to get past the World Cup group stage?', '<p>The North Africans do not boast household names that your average football fan would be familiar with. Instead, Tunisia relies on intangibles to compensate for a supposed lack of talent on paper.</p>\r\n<p>&ldquo;Grinta&rdquo; (Italian for grit) has become the national team&rsquo;s ethos and it perfectly encapsulates the underdog spirit the Tunisians embody on the pitch.</p>\r\n<p>Historically, they have employed those intangibles to trigger trailblazing accomplishments at the&nbsp;<a href=\"https://www.aljazeera.com/qatar-world-cup-2022/\">World Cup</a>. For instance, Tunisia made history in 1978 by defeating Mexico 3-1 in the first match of the group stages, becoming the first African or Arab country to win a match at a World Cup.</p>\r\n<p>Unfortunately, subsequent appearances at the tournament failed to live up to those standards that Tarek Dhiab&rsquo;s golden generation set in Argentina. In fact, of the five African representatives in Qatar, Tunisia are the only ones that have never managed to get past the group stages.</p>\r\n<p>Supporters of the Carthage Eagles, who will be numerous in Qatar, understand that they are, once again, not favoured to qualify for the knockout stages. Notwithstanding, coach Jalel Kadri&rsquo;s men will not curb their ambition and they will be a tough challenge for Denmark, Austria and France in Group D.</p>', 'upload/300927c1cd.jpg', 'Al-amin', 'tunishia,2022', '2022-11-08 12:51:48', 1),
(30, 0, 'Brazil announces 26-man squad for 2022 Qatar World Cup', '<p>Brazil are the only country to have won the&nbsp;<a href=\"https://khelnow.com/football/2022-11-world-football-fifa-world-cup-top-10-countries-with-most-appearances\">World Cup five times</a>. However, they have not qualified for the finals since 2002. They have exited in the quarterfinals in 2006, 2010, and 2018 since winning the coveted trophy in 2002.</p>\r\n<p>The Selecao came close to reaching the&nbsp;<a href=\"https://khelnow.com/tag/fifa-world-cup/\">World Cup</a>&nbsp;final in 2014, but a painful defeat by Germany in the semi-finals has left Brazil as a decent nation.</p>\r\n<p>However, due to their outstanding squad quality and depth, they are always considered favourites in every World Cup. This time, the South American giants will enter the World Cup as big contenders, with Neymar and the company ensuring that the Jules Rimet trophy returns to Brazil, and they will be attempting to become the first non-European country to win the World Cup since 2002.</p>', 'upload/f6165f7e60.jpg', 'Faysal', 'brazil, squad', '2022-11-08 12:54:48', 1),
(34, 0, '‘Racism’: Qataris decry French cartoon of national football team', '<p>A cartoon by a French newspaper depicting Qatari footballers as terrorists has sparked outrage on social media, with users calling out its &ldquo;blatant Islamophobia&rdquo; and &ldquo;racism&rdquo;.</p>\r\n<p>The caricature was published by Le Canard enchain&eacute; in its October issue, which focuses on Qatar and its role as the FIFA World Cup 2022 host.</p>\r\n<p>The image depicts seven bearded men with &ldquo;Qatar&rdquo; written across their chests above big numbers. They appear to be chasing a football in the sand while carrying machetes, guns and rocket launchers. One wears a belt laden with explosives. Five are wearing blue robes and two are wearing black shirts and pants with balaclavas covering their faces.</p>\r\n<p>Five men in white robes are drawn on the sidelines, looking on.</p>', 'upload/77b19ef94b.jpg', 'Monir', 'qatar,racism', '2022-11-08 13:14:13', 1),
(35, 1, 'Jordan coach: ‘Morocco can be the dark horse of World Cup 2022’', '<p>Jordan&rsquo;s football team failed to qualify for the World Cup 2022 that takes place in the Middle East for first time but the team&rsquo;s manager is still excited to watch the tournament from the stands.</p>\r\n<p>Adnan Hamad, hailing from Iraq, failed to lead his team to the World Cup after being eliminated by Australia in the second round of qualifiers.</p>\r\n<p>The 61-year-old was first called up to the Iraq national team as a player in the 1984 Gulf Cup. From 2009 to 2013, he coached Jordan&rsquo;s national team and led them to the 2011 Asian Cup quarter-finals and the playoff round of the 2014 World Cup qualifiers.</p>\r\n<p>Here, he talks to Al Jazeera about Jordan&rsquo;s team failing to make the World Cup and gives his predictions on how the Arab teams will perform:</p>', 'upload/3dfb767966.jpg', 'Al-amin', 'jordan,morocco', '2022-11-08 13:17:20', 1),
(36, 1, 'FIFA World Cup 2022: Argentina fans in Qatar gear up to back Messi', '<p><span>n advanced guard of Argentina football fans chanted their certainty that Lionel Messi&rsquo;s last World Cup will end in success Monday ahead of the Latin American side becoming the first to set up their base camp in Qatar.</span></p>\r\n<p>Scores of fans gathered at the World Cup countdown clock on Doha&rsquo;s seafront chanting Messi&rsquo;s name and waving flags, 13 days before the tournament starts, as bemused police watched the mounting football fever in the Gulf state.</p>\r\n<p>Many went to the clock to welcome Mat&iacute;as Villarroel, Silvio Gatti, Leandro Blanco and Lucas Ledezma who cycled 10,500 kilometers (6,500 miles) across Africa to reach Doha on Monday. But Messi was on the minds of the riders and the other fans.</p>\r\n<p>&ldquo;The dream behind cycling this whole route is that Argentina will win the World Cup and that Leo will lift the trophy on December 18,&rdquo; said Blanco.</p>\r\n<p>While Argentina won the World Cup in 1978 and 1986, Messi, one of the greatest players ever, has only been a losing finalist, in 2014.</p>\r\n<p>&ldquo;The emotion we feel here is immense, we spent six months cycling through Africa and the Middle East, to be here in Doha today and for this party.&rdquo;</p>\r\n<div class=\"img-full-width \">&nbsp;</div>', 'upload/964b35494b.jpg', 'Al-amin', 'messi,2022,argentina,fans', '2022-11-08 13:20:42', 1),
(37, 1, 'FIFA World Cup 2022 to be played from Nov 20 in Qatar', '<p><span>FIFA World Cup 2022 will be played from 20th November to 18th December this year across five cities in Qatar.&nbsp;It is the first football World Cup to be held in winter, as well as the first to be hosted by an Arab country.</span></p>\r\n<p>France is the defending champions. In the inaugural match, hosts Qatar will take on South American outfit Ecuador at the Al Bayt Stadium on the 20th of November.</p>\r\n<p>The tournament will be played across eight venues. 28 teams have been placed in eight groups.The final is set to be played at the Lusail Stadium on the 18th of December.</p>\r\n<p>Meanwhile, Brazil Football Association has named a 26-man World Cup squad for the Qatar world cup. Brazil&rsquo;s national team coach Tite announced his list of players at a news conference in Rio de Janeiro yesterday.</p>\r\n<p>Arsenal&rsquo;s Gabriel Martinelli has been included in a list dominated by 12 players from the English Premier League. Brazil will open their World Cup campaign against Serbia on the 24th of November.</p>', 'upload/de0223a747.jpg', 'Faysal', '2022,fifa,qatar', '2022-11-08 13:22:27', 1),
(38, 1, 'Labour Rights Legacy of the FIFA World Cup', '<p>On 18 December 2022, the Men&rsquo;s World Cup football final will be held at Qatar&rsquo;s Lusail Stadium. It will mark the end of a journey that started in December 2010 when Qatar was awarded the tournament hosting rights.&nbsp;&nbsp;</p>\r\n<p>18 December is also International Migrants Day, a day set aside to honour migrant workers for their contributions and sacrifice.&nbsp;It is also Qatar&rsquo;s National Day.</p>\r\n<p>Over the past 12 years, millions of migrant workers have toiled to make the 2022 World Cup possible, building key infrastructure, including the stadiums in Qatar. However, these workers have always been at the margins, and the authorities have been less than responsive to their abusive work conditions.&nbsp;</p>\r\n<p>Qatar&rsquo;s Labour Minister recently&nbsp;<a href=\"https://amp.france24.com/en/live-news/20221102-qatar-rejects-compensation-fund-for-world-cup-migrant-workers\" rel=\"noopener noreferrer\" target=\"_blank\">rejected</a>&nbsp;proposals for&nbsp;a remedy fund for abuses faced by migrant workers, including uncompensated deaths, further highlighting the lack of recognition for the people who perform the vast majority of the country&rsquo;s labour. FIFA, football&rsquo;s governing body, has not made a decision.&nbsp;&nbsp;</p>\r\n<p>But South Asian governments, too, share responsibility for these abuses. They wasted many opportunities to collectively push for reforms to address shared concerns, including numerous unexplained, uninvestigated and uncompensated deaths, high recruitment fees, and wage abuses.&nbsp;</p>\r\n<p>The preparations for the tournament owe a lot to South Asia. It is not just that the footballs are made in&nbsp;<a href=\"https://dailytimes.com.pk/954864/sialkot-made-footballs-to-be-used-in-fifa-world-cup-2022/\" rel=\"noopener noreferrer\" target=\"_blank\">Sialkot, Pakistan</a>. Every state-of-the-art stadium in Qatar, and all of the&nbsp;<a href=\"https://dohanews.co/why-is-qatars-fifa-world-cup-the-most-expensive-in-history/\" rel=\"noopener noreferrer\" target=\"_blank\">US$220 billion</a>&nbsp;in surrounding infrastructure, is largely built by South Asians. Migrant workers from the region are also employed in stadiums, hotels, malls, and airports, providing key services. The remittances these workers send to their families are critical to make ends meet&mdash;often the only source of income for many families.&nbsp;</p>\r\n<p>FIFA, football&rsquo;s global governing body, has been a complacent enabler of abuses, while Qatar, the host country, has faced well-deserved criticism for the high human cost of the Road to 2022.&nbsp;FIFA did not carry out human rights due diligence over the abusive&nbsp;kafala&nbsp;labour sponsorship system in Qatar, or the prohibitions in Qatar that keep workers from forming unions or striking.&nbsp;&nbsp;</p>\r\n<p>After years of pressure over the conditions, the Qatari government introduced reforms that partially addressed key abuses. The government set up a Workers&rsquo; Support and Insurance Fund that became operational in 2020 to ensure that workers are paid even when companies fail to do so. Over $320 million has been disbursed as of September 2022 &mdash; an indication of the wide-scale nature of the problem.&nbsp;&nbsp;</p>\r\n<p>Such initiatives have had immediate impact on families far away. One South Asian worker&nbsp;<a href=\"https://www.hrw.org/news/2022/08/12/fifa/qatar-commit-compensate-abused-migrant-workers\">told</a>&nbsp;Human Rights Watch in July that he waited months for the system to process his request and send his money, even contemplating suicide, knowing his family had to take loans for his children&rsquo;s education and parents&rsquo; health bills.&nbsp;&nbsp;&nbsp;</p>\r\n<p>Furthermore, only a small fraction of workers secured jobs without paying illegal recruitment fees. One lucky worker&nbsp;<a href=\"https://www.hrw.org/news/2022/10/20/qatar/fifa-reimburse-migrant-workers-recruitment-fees\">said,</a>&nbsp;&ldquo;If I had not come for free and had paid recruitment fees as is common for Indians, my first paycheck would be going to the local money lender back home, and not to my mother.&rdquo;&nbsp;</p>\r\n<p>But most of the migrant workers &lsquo;paid to build&rsquo; the multibillion infrastructure project in the scorching heat. A 2020&nbsp;<a href=\"https://www.ilo.org/wcmsp5/groups/public/---asia/---ro-bangkok/---ilo-dhaka/documents/publication/wcms_766198.pdf\" rel=\"noopener noreferrer\" target=\"_blank\">survey</a>&nbsp;found that the average recruitment costs for Bangladeshis going to work in Qatar was around $3,863, equivalent to 18 months of earnings in Qatar. A significant portion of the remittances are simply spent to pay off loans taken to get these jobs.&nbsp;</p>\r\n<p>Companies affiliated with Qatar&rsquo;s Supreme Committee for Delivery and Legacy, the body responsible for planning and delivering World Cup infrastructure, have committed to reimburse over $28 million in recruitment fees to 48,814 workers in Qatar. While a positive initiative, its impact is inadequate considering that it does not cover most migrant workers who helped build and service the necessary infrastructure for the World Cup. At any given time, there are over 2.2 million temporary migrant workers in the country.&nbsp;</p>\r\n<p>Qatar deserves credit for attempting reforms, but the benefits have been limited due to their late introduction, narrow scope, or poor enforcement. This is why Human Rights Watch, Amnesty International and other organisations have called on FIFA and Qatari authorities to remedy past and ongoing abuses during World Cup preparations, including deaths, injuries and wage theft.&nbsp;</p>\r\n<p>Despite growing pressure from sponsors, football associations, former players and fans, FIFA is dragging its feet while the Qatari Labour Minister rejected the call last week, labelling it &ldquo;a publicity stunt.&rdquo;&nbsp;</p>\r\n<p>Qatar and FIFA still have a chance to shape the legacy of the World Cup. They have the resources and responsibility to remedy these abuses.&nbsp;</p>\r\n<p>The labour minister&nbsp;<a href=\"https://amp.france24.com/en/live-news/20221102-qatar-rejects-compensation-fund-for-world-cup-migrant-workers\" rel=\"noopener noreferrer\" target=\"_blank\">said</a>&nbsp;that &ldquo;every death is a tragedy&rdquo;. But the greatest tragedy is that the authorities failed to properly investigate the causes of many worker deaths, deeming them &lsquo;natural&rsquo;, &lsquo;unexplained&rsquo;, or &lsquo;cardiac arrests&rsquo;, leaving their families without compensation because these causes are not considered work-related. Without adequate investigation, deaths caused by working conditions such as heat stress have gone uncompensated.&nbsp;&nbsp;</p>\r\n<p>FIFA has provided a total of $260 million of what it calls &lsquo;legacy funds&rsquo; for humanitarian causes to host countries for three previous tournaments: in South Africa (2010), Brazil (2014) and Russia (2018). Qatar should be no different. It needs to set up a remedy fund for abused workers and the families of those who died unless it wants its legacy for the 2022 World Cup to be about worker abuse.&nbsp;</p>\r\n<p>There is one last opportunity for South Asian governments to back the call for a remedy and to work to ensure stronger protections for their workers. In particular, they are well placed to respond to&nbsp;<a href=\"https://amp.france24.com/en/live-news/20221102-qatar-rejects-compensation-fund-for-world-cup-migrant-workers\" rel=\"noopener noreferrer\" target=\"_blank\">Qatari authorities</a>&nbsp;who claimed there is no data to establish these funds, with the Qatar Labour Minister&nbsp;<a href=\"https://amp.france24.com/en/live-news/20221102-qatar-rejects-compensation-fund-for-world-cup-migrant-workers\" rel=\"noopener noreferrer\" target=\"_blank\">asking</a>: &ldquo;Where are the victims, do you have names of the victims, how can you get these numbers?&rdquo;</p>\r\n<p>South Asian governments can be an important resource to connect FIFA and Qatari authorities with families of migrant workers. This requires a detailed review of the existing databases and welfare systems.&nbsp;The Qatar government and origin country governments also have&nbsp;<a href=\"https://www.hrw.org/news/2022/07/11/families-bring-home-migrant-worker-remains-qatar\">data</a>&nbsp;of worker deaths because of the bureaucracy that families have to navigate to repatriate deceased loved ones. Origin country governments can also seek support from local&nbsp;<span class=\"onomasticon onomasticon-cursor-default\" title=\"civil society\" data-tooltip=\"Civil society usually refers to a broad array of nongovernmental organizations including: community and grassroots groups, advocacy organizations, religious-based groups, labor unions, and many others. Civil society typically does what the government or businesses cannot or won&rsquo;t do, such as providing direct services or advocating for changes in the laws and government practices.\">civil society</span>&nbsp;groups and media to locate families of deceased workers and other victims, putting out calls for information on national media outlets and government websites.&nbsp;</p>\r\n<p>The problem of establishing a compensation fund for migrant workers and their families has never been about data, &mdash;which is available, but about political will.&nbsp;</p>\r\n<p>Only if there is remedy will this tumultuous, 12-year journey end on a more humane note on 18 December 18, the day of the final of the 2022 World Cup, and more important, the International Migrants Day and Qatar&rsquo;s National Day.&nbsp;</p>', 'upload/c49b52cffe.jpg', 'Siam', 'labour, rights, 2022', '2022-11-08 13:26:16', 1),
(39, 2, 'Argentina vs France, FIFA World Cup 2018: France beat Argentina', '<p><span>FT - France beat Argentina 4-3.</span></p>\r\n<p>Kylian Mbappe eclipsed Lionel Messi as France reached the World Cup quarter-finals after a thrilling 4-3 win over Argentina in Kazan.</p>\r\n<p>The Paris Saint-Germain teenager won a 13th-minute penalty for Antoine Griezmann with a storming 75-yard run and scored two goals in five minutes (64, 68) after the break as Didier Deschamps\' side overcame the setback of going behind to claim a convincing victory.</p>\r\n<div class=\"sdc-site-outbrain sdc-site-outbrain--AR_5\" data-component-name=\"sdc-site-outbrain\" data-target=\"\" data-widget-mapping=\"\" data-installation-keys=\"\" data-init=\"true\">\r\n<div class=\"OUTBRAIN\" data-src=\"https://www.skysports.com/football/france-vs-argentina/report/385218\" data-ob-template=\"365MediaGroup\" data-widget-placement=\"\" data-widget-id=\"AR_5\" data-is-secured=\"true\" data-consent-string=\"\" data-consent-version=\"2\">&nbsp;</div>\r\n</div>\r\n<p>Argentina had hit back through a 30-yard Angel di Maria strike (41) and a fortuitous flick from Gabriel Mercado three minutes after the restart but they were outplayed for prolonged periods in a game that could be Messi\'s last on the global stage.</p>\r\n<div class=\"sdc-article-widget sdc-site-oddschecker\" data-component-name=\"sdc-site-oddschecker\">&nbsp;</div>\r\n<p>Benjamin Pavard\'s 57th-minute half-volley - his first France goal - sparked a second-half surge and though substitute Sergio Aguero threatened a late twist with an injury-time header, Mbappe\'s double proved decisive, setting up a last-eight tie against Uruguay.</p>\r\n<p><br /><br /></p>\r\n<div>&nbsp;</div>', 'upload/db723b1f5f.jpg', 'Al-amin', 'argentina, france,2018', '2022-11-08 17:13:55', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_slider`
--

CREATE TABLE `tbl_slider` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_slider`
--

INSERT INTO `tbl_slider` (`id`, `title`, `image`) VALUES
(1, 'Our golden dream!', 'upload/slider/9773f8bd19.jpg'),
(2, 'Here we go!', 'upload/slider/0a89acff04.jpg'),
(4, 'Be wondered by this wonderful!', 'upload/slider/2a37c955d4.jpg'),
(5, 'let\'s go Qatar!', 'upload/slider/d545df8659.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_social`
--

CREATE TABLE `tbl_social` (
  `id` int(11) NOT NULL,
  `fb` varchar(255) NOT NULL,
  `tw` varchar(255) NOT NULL,
  `ln` varchar(255) NOT NULL,
  `gp` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_social`
--

INSERT INTO `tbl_social` (`id`, `fb`, `tw`, `ln`, `gp`) VALUES
(1, 'http://facebook.com', 'http://twitter.com', 'http://linkedin.com', 'http://google.com');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_theme`
--

CREATE TABLE `tbl_theme` (
  `id` int(11) NOT NULL,
  `theme` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_theme`
--

INSERT INTO `tbl_theme` (`id`, `theme`) VALUES
(1, 'green');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(32) NOT NULL,
  `email` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `username`, `password`, `email`, `details`, `role`) VALUES
(1, 'Shahade Parveze Siam', 'Siam', '202cb962ac59075b964b07152d234b70', 'siam.cse6.bu@gmail.com', '<p>Shahade Parveze&nbsp;&nbsp;Siam is the admin of FifaFever.</p>', 0),
(8, 'Shahade Parveze Siam', 'Siam', '81dc9bdb52d04dc20036dbd8313ed055', 'siam.cse28@gmail.com', '<p>A student of CSE department at University of Barishal. Alhamdulillah Muslim.</p>', 1);

-- --------------------------------------------------------

--
-- Table structure for table `title_slogan`
--

CREATE TABLE `title_slogan` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slogan` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `title_slogan`
--

INSERT INTO `title_slogan` (`id`, `title`, `slogan`, `logo`) VALUES
(1, 'FifaFever', 'The Greatest Show on Earth!', 'upload/logo.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_footer`
--
ALTER TABLE `tbl_footer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_page`
--
ALTER TABLE `tbl_page`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_post`
--
ALTER TABLE `tbl_post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_social`
--
ALTER TABLE `tbl_social`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_theme`
--
ALTER TABLE `tbl_theme`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `title_slogan`
--
ALTER TABLE `title_slogan`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_footer`
--
ALTER TABLE `tbl_footer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_page`
--
ALTER TABLE `tbl_page`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_post`
--
ALTER TABLE `tbl_post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_social`
--
ALTER TABLE `tbl_social`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_theme`
--
ALTER TABLE `tbl_theme`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `title_slogan`
--
ALTER TABLE `title_slogan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
