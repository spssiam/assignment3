<?php
define("DB_HOST", "sql300.epizy.com");
define("DB_USER", "epiz_32995674");
define("DB_PASS", "6ld87wYp9zZNCU");
define("DB_NAME", "epiz_32995674_crudsiam");
define("TITLE", "fifa world cup");
define("KEYWORDS", "fifa,fever,world,cup,");
?>

